Version 4
SymbolType CELL
LINE Normal -32 36 32 36
LINE Normal -32 60 32 60
LINE Normal 0 96 0 76
LINE Normal 0 16 0 36
LINE Normal -20 24 -12 24
LINE Normal -16 20 -16 28
RECTANGLE Normal -16 44 16 52
RECTANGLE Normal -16 68 16 76
WINDOW 0 24 16 Left 2
SYMATTR Description LiPo Battery
SYMATTR Prefix X
SYMATTR Value LiPoBat
SYMATTR SpiceLine Vnom=4.2 ah=2200m SOC=1 Vdah=2.0
PIN 0 16 NONE 0
PINATTR PinName BP
PINATTR SpiceOrder 1
PIN 0 96 NONE 0
PINATTR PinName BN
PINATTR SpiceOrder 2
