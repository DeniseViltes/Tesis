*PADS-LIBRARY-PART-TYPES-V9*

FDMS6681Z FDMS6681Z I TRX 7 1 0 0 0
TIMESTAMP 2025.11.19.03.56.34
"Mouser Part Number" 512-FDMS6681Z
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ON-Semiconductor-Fairchild/FDMS6681Z?qs=eQsPqqG3NqYIemB4oC6BVw%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" FDMS6681Z
"Description" Max rDS(on) = 5.0 m at VGS = -4.5 V, ID = -15.7 A ; HBM ESD protection level of 8kV typical (Note 3); RoHS Compliant ; Advanced Package and Silicon combination for low rDS(on) and high efficiency ; Max rDS(on) = 3.2 m at VGS = -10 V, ID = -21.1 A ; MSL1 robust package design
"Datasheet Link" https://www.onsemi.com/pub/Collateral/FDMS6681Z-D.PDF
"Geometry.Height" 1.1mm
GATE 1 9 0
FDMS6681Z
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4
9 0 U D_5

*END*
*REMARK* SamacSys ECAD Model
1083998/1825778/2.50/9/2/MOSFET (P-Channel)
